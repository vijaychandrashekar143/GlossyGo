document.addEventListener('DOMContentLoaded', () => {
    let currentStep = 0;
    const forms = document.querySelectorAll('.step');

    function showStep(step) {
        forms.forEach((form, index) => {
            form.style.display = index === step ? 'block' : 'none';
        });
    }

    showStep(currentStep);

    // Handle customer details submission
    document.getElementById('customerDetailsForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const customerName = document.getElementById('customerName').value;
        const phoneNumber = document.getElementById('phoneNumber').value;
        const address = document.getElementById('address').value;
        const carModel = document.getElementById('carModel').value;

        if (customerName && phoneNumber && address && carModel) {
            localStorage.setItem('customerName', customerName);
            localStorage.setItem('phoneNumber', phoneNumber);
            localStorage.setItem('address', address);
            localStorage.setItem('carModel', carModel);
            currentStep++;
            showStep(currentStep);
        } else {
            alert("Please fill in all fields before proceeding.");
        }
    });

    // Handle service selection
    document.getElementById('serviceForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const selectedService = document.querySelector('input[name="service"]:checked');
        if (selectedService) {
            const service = selectedService.value;
            const price = selectedService.getAttribute('data-price');
            localStorage.setItem('service', service);
            localStorage.setItem('servicePrice', price);
            currentStep++;
            showStep(currentStep);
        } else {
            alert("Please select a service before proceeding.");
        }
    });

    // Handle time slot selection
    document.getElementById('timeSlotForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const timeSlot = document.getElementById('timeSlot').value;

        if (timeSlot) {
            localStorage.setItem('timeSlot', timeSlot);
            const customerName = localStorage.getItem('customerName');
            const phoneNumber = localStorage.getItem('phoneNumber');
            const address = localStorage.getItem('address');
            const carModel = localStorage.getItem('carModel');
            const service = localStorage.getItem('service');
            const servicePrice = localStorage.getItem('servicePrice');

            const confirmationMessage = `Thank you, ${customerName}! You have booked a ${service} for your ${carModel} at ₹${servicePrice} on ${timeSlot}.`;
            document.getElementById('confirmationMessage').innerText = confirmationMessage;

            // Create WhatsApp message
            if (/^\d{10}$/.test(phoneNumber)) {
                const whatsappMessage = `Booking Details:\nName: ${customerName}\nPhone: ${phoneNumber}\nAddress: ${address}\nCar Model: ${carModel}\nService: ${service} - ₹${servicePrice}\nTime Slot: ${timeSlot}`;
                const whatsappLink = `https://wa.me/8123917151?text=${encodeURIComponent(whatsappMessage)}`;
                document.getElementById('whatsappLink').href = whatsappLink;

                // Show confirmation
                currentStep++;
                showStep(currentStep);
            } else {
                alert("Please enter a valid phone number.");
            }
        } else {
            alert("Please select a time slot before proceeding.");
        }
    });

    // Display booking confirmation
    if (document.getElementById('confirmationMessage')) {
        const customerName = localStorage.getItem('customerName');
        const phoneNumber = localStorage.getItem('phoneNumber');
        const address = localStorage.getItem('address');
        const carModel = localStorage.getItem('carModel');
        const service = localStorage.getItem('service');
        const servicePrice = localStorage.getItem('servicePrice');
        const timeSlot = localStorage.getItem('timeSlot');

        if (service && carModel && timeSlot) {
            document.getElementById('confirmationMessage').innerText = `Your booking for a ${service} on your ${carModel} at ₹${servicePrice} has been confirmed for ${timeSlot}!`;
        } else {
            document.getElementById('confirmationMessage').innerText = "No booking information found.";
        }
    }
});
